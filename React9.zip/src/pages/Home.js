import React from 'react';
import { Link } from 'react-router-dom';
import '../styles/Home.css';

const HomePage = ({ tasks }) => {
  return (
    <div className='homeContainer'>
      <div className='homeFlex'>
        {tasks.map((task) => (
          <div class="card" key={task.id}>
            <div class="card-details">
              <p class="text-title">{task.title}</p>
              <p class="text-body">{task.description}</p>
            </div>
            <Link to={`/detalle/${task.id}`}>
              <button class="card-button">Detalles</button>
            </Link>
          </div>
        ))}
      </div>
    </div>
  );
};

export default HomePage;
